/*  Parse_util header */

#define MAX_WORDS   20
#define MAX_LINE    100
char **parse_split(char *line);
int parse_numwords(char **words);


